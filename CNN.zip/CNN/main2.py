import os
import cv2
import face_recognition
import numpy as np
import math

def face_confidence(face_distance, face_match_threshold=0.6):
    range = (1.0 - face_match_threshold)
    linear_val = (1.0 - face_distance) / (range * 2.0)

    if face_distance > face_match_threshold:
        return str(round(linear_val * 100, 2)) + '%'
    else:
        value = (linear_val + ((1.0 - linear_val) * math.pow((linear_val - 0.5) * 2, 0.2))) * 100
        return str(round(value, 2)) + '%'

class FaceRecognition:
    known_face_encodings = []
    known_face_names = []

    def __init__(self):
        self.encode_faces()

    def encode_faces(self):
        for image in os.listdir('CNN/faces'):
            face_image = face_recognition.load_image_file(f'CNN/faces/{image}')
            face_encoding = face_recognition.face_encodings(face_image)
            if face_encoding:
                self.known_face_encodings.append(face_encoding[0])
                # Store the name without the file extension
                name, _ = os.path.splitext(image)
                self.known_face_names.append(name)
            else:
                print(f"No face found in {image}")

        print(f"Encoded faces: {self.known_face_names}")

    def recognize_faces_in_image(self, image_path):
        image = face_recognition.load_image_file(image_path)
        face_locations = face_recognition.face_locations(image)
        face_encodings = face_recognition.face_encodings(image, face_locations)

        face_names = []
        for face_encoding in face_encodings:
            matches = face_recognition.compare_faces(self.known_face_encodings, face_encoding)
            name = 'Unknown'
            confidence = 'Unknown'
            face_distances = face_recognition.face_distance(self.known_face_encodings, face_encoding)

            best_match_index = np.argmin(face_distances)

            if matches[best_match_index]:
                name = self.known_face_names[best_match_index]
                confidence = face_confidence(face_distances[best_match_index])

            face_names.append(f'{name} ({confidence})' if name != 'Unknown' else name)

        return face_locations, face_names

    def process_images(self, image_directory):
        for image_name in os.listdir(image_directory):
            image_path = os.path.join(image_directory, image_name)
            face_locations, face_names = self.recognize_faces_in_image(image_path)

            image = cv2.imread(image_path)
            for (top, right, bottom, left), name in zip(face_locations, face_names):
                cv2.rectangle(image, (left, top), (right, bottom), (0, 0, 255), 2)
                cv2.rectangle(image, (left, bottom - 35), (right, bottom), (0, 0, 255), -1)
                cv2.putText(image, name, (left + 6, bottom - 6), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 1)

            cv2.imshow('Image', image)
            cv2.waitKey(0)
            cv2.destroyAllWindows()

if __name__ == '__main__':
    fr = FaceRecognition()
    fr.process_images('CNN/faces')
