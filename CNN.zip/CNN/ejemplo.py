import face_recognition
import cv2

# Cargar una imagen de prueba
image = face_recognition.load_image_file("CNN/faces/andrew.jpg")
face_locations = face_recognition.face_locations(image)
face_encodings = face_recognition.face_encodings(image, face_locations)

print(f"Detected face locations: {face_locations}")
print(f"Detected face encodings: {face_encodings}")

# Mostrar la imagen con las ubicaciones de las caras
for (top, right, bottom, left) in face_locations:
    cv2.rectangle(image, (left, top), (right, bottom), (0, 0, 255), 2)

cv2.imshow('Image', image)
cv2.waitKey(0)
cv2.destroyAllWindows()
